from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application configuration.

    Values are loaded from environment variables
    and the .env file.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=True,
        extra="ignore",
    )

    #
    # Application
    #

    app_name: str = Field(
        default="Enterprise AI Assistant",
        alias="APP_NAME",
    )

    app_version: str = Field(
        default="1.0.0",
        alias="APP_VERSION",
    )

    environment: str = Field(
        default="development",
        alias="ENVIRONMENT",
    )

    #
    # OpenAI
    #

    openai_api_key: str = Field(
        alias="OPENAI_API_KEY",
    )

    openai_chat_model: str = Field(
        default="gpt-4.1",
        alias="OPENAI_CHAT_MODEL",
    )

    openai_embedding_model: str = Field(
        default="text-embedding-3-small",
        alias="OPENAI_EMBEDDING_MODEL",
    )

    #
    # Server
    #

    host: str = Field(
        default="127.0.0.1",
        alias="HOST",
    )

    port: int = Field(
        default=8000,
        alias="PORT",
    )

    #
    # Logging
    #

    log_level: str = Field(
        default="INFO",
        alias="LOG_LEVEL",
    )


@lru_cache
def get_settings() -> Settings:
    """
    Create a cached Settings instance.

    Using lru_cache ensures the configuration
    is loaded only once during the application's
    lifetime.
    """

    return Settings()


settings = get_settings()